<!DOCTYPE html>

<!-- paulirish.com/2008/conditional-stylesheets-vs-css-hacks-answer-neither/ -->
<!--[if lt IE 7]> <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="sv"> <![endif]-->
<!--[if IE 7]>    <html class="no-js lt-ie9 lt-ie8" lang="sv"> <![endif]-->
<!--[if IE 8]>    <html class="no-js lt-ie9" lang="sv"> <![endif]-->
<!--[if gt IE 8]><!--> 
<html class="no-js" lang="sv">
	<!--<![endif]-->
	<head>
		<meta charset="utf-8" />

		<!-- Set the viewport width to device width for mobile -->
		<meta name="viewport" content="width=device-width" />

		<title>Welcome to Foundation</title>

		<!-- Included CSS Files -->
		<link rel="stylesheet" href="<?php echo TEMPLATE_DIR; ?>/stylesheets/foundation-style/globals.css">
		<link rel="stylesheet" href="<?php echo TEMPLATE_DIR; ?>/stylesheets/foundation-style/typography.css">
		<link rel="stylesheet" href="<?php echo TEMPLATE_DIR; ?>/stylesheets/foundation-style/grid.css">
		<link rel="stylesheet" href="<?php echo TEMPLATE_DIR; ?>/stylesheets/foundation-style/ui.css">
		<link rel="stylesheet" href="<?php echo TEMPLATE_DIR; ?>/stylesheets/foundation-style/buttons.css">
		<link rel="stylesheet" href="<?php echo TEMPLATE_DIR; ?>/stylesheets/foundation-style/tabs.css">
		<link rel="stylesheet" href="<?php echo TEMPLATE_DIR; ?>/stylesheets/foundation-style/navbar.css">
		<link rel="stylesheet" href="<?php echo TEMPLATE_DIR; ?>/stylesheets/foundation-style/forms.css">
		<link rel="stylesheet" href="<?php echo TEMPLATE_DIR; ?>/stylesheets/foundation-style/orbit.css">
		<link rel="stylesheet" href="<?php echo TEMPLATE_DIR; ?>/stylesheets/foundation-style/reveal.css">
		<link rel="stylesheet" href="<?php echo TEMPLATE_DIR; ?>/stylesheets/app.css">

		<script src="<?php echo TEMPLATE_DIR; ?>/javascripts/foundation/modernizr.foundation.js"></script>

		<!-- IE Fix for HTML5 Tags -->
		<!--[if lt IE 9]>
		<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->

	</head>
	<body>
	
		<div class="row" id="head">
			<div class="twelve columns">
				<header>
					<h1>Välkommen till Nybyggarscout i Linköping!</h1>
					
					<div id="featured">
					  <img src="<?php echo TEMPLATE_DIR; ?>/images/header/spinner1.jpg" alt="" />
					  <img src="<?php echo TEMPLATE_DIR; ?>/images/header/spinner2.jpg" alt="" />
					  <img src="<?php echo TEMPLATE_DIR; ?>/images/header/spinner4.jpg" alt="" />
					  <img src="<?php echo TEMPLATE_DIR; ?>/images/header/spinner5.jpg" alt="" />
					  <img src="<?php echo TEMPLATE_DIR; ?>/images/header/spinner6.jpg" alt="" />
					  <img src="<?php echo TEMPLATE_DIR; ?>/images/header/spinner7.jpg" alt="" />
					  <img src="<?php echo TEMPLATE_DIR; ?>/images/header/spinner8.jpg" alt="" />
					</div>
					
				</header>	
			</div>		
		</div>
		<div class="row">
			<div class="twelve columns">
				<hr />
			</div>
		</div>
		<div class="row">
			<div class="eight columns">				
				<h2>Kristus har segrat! - Vi kan segra!</h2>
				<div style="margin-top:25px;">
					<a href="#"><img style="padding:10px;display:inline;" src="<?php echo TEMPLATE_DIR; ?>/images/index/information.jpg" width="208" height="176" alt="" /></a>
					<a href="#"><img style="padding:10px;display:inline;" src="<?php echo TEMPLATE_DIR; ?>/images/index/bilder.jpg" width="208" height="176" alt="" /></a>
					<a href="#"><img style="padding:10px;display:inline;" src="<?php echo TEMPLATE_DIR; ?>/images/index/kontakt.jpg" width="208" height="176" alt="" /></a>
				</div>
				<!--
				<div id="where" class="ten columns offset-by-one last">
					<dl class="vertical tabs">
					  <dd><a href="#vertical1">Jag vill veta mer om vad nybyggarscout handlar om >></a></dd>
					  <dd><a href="#vertical2">Jag vill veta vad som händer nästa gång >></a></dd>
					  <dd><a href="#vertical3">Jag vill se bilder från lägret >></a></dd>
					</dl>
				</div>
				-->
				<!--
				<p id="welcome-button">
					<a href="#" class="large secondary button radius">Kom in >></a>
				</p>
				-->	
			</div>
			<div class="four columns">
				<div class="panel">
					<h5>Nybyggarscout i Linköping</h5>
  					<p>Nybyggarscout i Linköping är en kristen scoutliknande 
					verksamhet och är en del av barn- och ungdomsverksamheten 
					i Ryttargårdskyrkan i Linköping. Ryttargårdskyrkan är 
					en av församlingarna i Evangeliska Frikyrkan.</p>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="twelve columns">
				<hr />
			</div>
		</div>		
		<div class="row" id="foot">
			<div class="twelve columns centered ">
				<footer>					
					<p id="adress">
					  info@nybyggarscout.se &nbsp;|&nbsp; Ryttargårdskyrkan &nbsp;|&nbsp; 
					  Djurgårdsgatan 97 &nbsp;|&nbsp; 582 29 Linköping 
					</p>					
				</footer>	
			</div>	
		</div>	
		
	
				
		<!-- Included JS Files -->
		<script src="<?php echo TEMPLATE_DIR; ?>/javascripts/jquery.min.js"></script>
		<script src="<?php echo TEMPLATE_DIR; ?>/javascripts/foundation/jquery.reveal.js"></script>
		<script src="<?php echo TEMPLATE_DIR; ?>/javascripts/foundation/jquery.orbit-1.4.0.js"></script>
		<script src="<?php echo TEMPLATE_DIR; ?>/javascripts/foundation/jquery.customforms.js"></script>
		<script src="<?php echo TEMPLATE_DIR; ?>/javascripts/foundation/jquery.placeholder.min.js"></script>
		<script src="<?php echo TEMPLATE_DIR; ?>/javascripts/foundation/jquery.tooltips.js"></script>
		<script src="<?php echo TEMPLATE_DIR; ?>/javascripts/app.js"></script>
		
		<script type="text/javascript">
		    $(window).load(function() {
		         $('#featured').orbit({
		              bullets: true
		         });
		     });
		</script>		

	</body>
</html>
